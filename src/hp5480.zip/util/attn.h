extern int				Attn;

extern void				Attn_Init();
